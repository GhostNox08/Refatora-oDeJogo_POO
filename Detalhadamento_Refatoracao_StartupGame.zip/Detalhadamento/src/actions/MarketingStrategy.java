package actions;
import model.Startup;

public class MarketingDecisao implements DecisaoStrategy {
    public void aplicar(Startup startup) {
        // Lógica para efeito em receita base e reputação
    }
    public String getNome() { return "Marketing"; }
}
